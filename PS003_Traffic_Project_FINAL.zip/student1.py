
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error
import numpy as np

# Load cleaned traffic data
df = pd.read_csv("clean_traffic_data.csv")

# Select one traffic sensor
traffic = df["767523"]

# Use the previous 5 readings to predict the next reading
X = []
y = []

for i in range(5, len(traffic)):
    X.append(traffic.iloc[i-5:i].tolist())
    y.append(traffic.iloc[i])

# Split data by time: first 80% for training
split_index = int(len(X) * 0.8)

X_train = X[:split_index]
X_test = X[split_index:]
y_train = y[:split_index]
y_test = y[split_index:]

# Train the prediction model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict traffic readings
predictions = model.predict(X_test)

# Evaluate model performance
mae = mean_absolute_error(y_test, predictions)
rmse = np.sqrt(mean_squared_error(y_test, predictions))

print("Traffic prediction model trained successfully!")
print("Training samples:", len(X_train))
print("Testing samples:", len(X_test))
print("MAE:", round(mae, 3))
print("RMSE:", round(rmse, 3))

# Save actual and predicted readings
results = pd.DataFrame({
    "Actual Traffic": y_test,
    "Predicted Traffic": predictions
})

results.to_csv("prediction_results.csv", index=False)

print("\nPrediction results saved successfully!")

# Plot actual vs predicted traffic
import matplotlib.pyplot as plt

plt.figure(figsize=(12, 5))
plt.plot(y_test[:200], label="Actual Traffic")
plt.plot(predictions[:200], label="Predicted Traffic")

plt.title("Actual vs Predicted Traffic")
plt.xlabel("Test Reading")
plt.ylabel("Traffic Speed")
plt.legend()
plt.tight_layout()

plt.savefig("prediction_graph.png")
plt.show()

print("Prediction graph saved successfully!")
from sklearn.metrics import r2_score
r2 = r2_score(y_test, predictions)

print("R2 Score:", round(r2, 3))