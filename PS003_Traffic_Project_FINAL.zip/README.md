﻿# PS-003: Federated Traffic-Flow Prediction

## Project overview
This project explores traffic-flow prediction using the METR-LA dataset and a simplified federated-learning experiment.

## Method
- Input: previous 5 traffic readings.
- Target: the next traffic reading.
- Clients: 3.
- Federated rounds: 10.
- Local training epochs per client per round: 5.
- Model: SGDRegressor with weighted aggregation of client model parameters.

## Reported results
- Baseline MAE: 1.406789
- Federated MAE: 1.406638
- Baseline RMSE: 2.556219
- Federated RMSE: 2.553150
- Baseline R-squared: 0.511770
- Federated R-squared: 0.512941
- Estimated total communication: 2880 bytes (2.812 KiB)

Communication figures estimate model-parameter transfer only and exclude protocol overhead. Results are specific to this implementation and experimental setup.

## Setup
Install Python, then run:

    python -m pip install -r requirements.txt

Run the main experiment:

    python federated_learning.py

Generate the client communication comparison and graph:

    python client_comparison.py
    python communication_graph.py

Generate the final comparison graph and report:

    python final_comparison_graph.py
    python final_results_report.py

## Main output files
- `model_comparison.csv`: baseline versus federated metrics.
- `federated_prediction_results.csv`: federated predictions.
- `communication_cost.csv`: estimated communication cost.
- `client_communication_comparison.csv`: client-count communication comparison.
- `final_comparison_graph.png`: model comparison graph.
- `communication_graph.png`: communication-cost graph.

## Limitations
This is an experimental implementation, not a production federated-learning system. The communication calculation excludes network protocol overhead. Performance differences are small and should not be interpreted as proof that federated learning is generally more accurate.
